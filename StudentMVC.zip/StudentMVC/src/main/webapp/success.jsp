<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>Success</title></head>
<body><div class="container">
<h1>Student Added Successfully!</h1>
<a href="index.jsp">Add Another Student</a>
</div></body></html>
