<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Student Management System</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
<h1>Student Management System</h1>
<form action="addStudent" method="post">
<label>Name</label>
<input type="text" name="name" placeholder="Enter your name" required>

<label>Age</label>
<input type="number" name="age" min="1" max="100" placeholder="Enter your age" required>

<label>Course</label>
<input type="text" name="course" placeholder="Enter course" required>

<button type="submit">Add Student</button>
</form>
</div>
</body>
</html>
