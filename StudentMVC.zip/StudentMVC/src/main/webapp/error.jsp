<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>Error</title></head>
<body><div class="container">
<h1>Something went wrong!</h1>
<a href="index.jsp">Try Again</a>
</div></body></html>
